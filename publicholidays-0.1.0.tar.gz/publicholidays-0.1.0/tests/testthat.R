library(testthat)
library(publicholidays)

test_check("publicholidays")
