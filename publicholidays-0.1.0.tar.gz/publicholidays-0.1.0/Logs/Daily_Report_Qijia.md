# Daily Report Summary - Qijia Zheng

### Date: 2025/03/03
- choosed Nager.Date APIs
- brainstormed ideas for Nager.Date APIs

### Date: 2025/03/05
- decided the functions contained in this package

### Date: 2025/03/06
- learned how to build a R package
- learned how to write tests for R package

### Date: 2025/03/07
- developed the `ph_country_info` function

### Date: 2025/03/08
- developed the `ph_long_weekends` function

### Date: 2025/03/09
- developed the `ph_public_holidays` function

### Date: 2025/03/10
- tested the `ph_country_info` function

### Date: 2025/03/11
- tested the `ph_long_weekends` function

### Date: 2025/03/12
- tested the `ph_public_holidays` function

### Date: 2025/03/13
- built the integration test

### Date: 2025/03/14
- checked and optimized the performance of the functions according to test results

### Date: 2025/03/15
- modified test functions

### Date: 2025/03/16
- built the coverage report for the tests